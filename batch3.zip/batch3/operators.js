// ! arithmatic operator
// console.log(10 + 10);//! addition 
// console.log("10" + 10);//!1010 concetation 
// console.log(10 + 40 + "Hi");//!50Hi

// console.log("JS"+50+50);//!JS5050
// console.log("JS"+(50+50));//! JS100

// console.log(10-5);
// console.log("10" - 5);//! typecasting
// console.log("10" - "hi");//! NaN
// console.log("10" - "5");

// console.log(5*5);
// console.log("5"*5);//! typecasting

// console.log(10/2);
// console.log("10"/2);//! typecasting


// console.log(10 % 2);//! 
// console.log("10"% "2");//! typecasting

// console.log(2**5);
// console.log("2"**5);//! typecasting

// let a =10;
// console.log(++a);
// console.log(a++);
// console.log(a);

// console.log(--a);//! 9
// console.log(a)

//!assignment operator:-
// let a = 10;
// console.log(a);
// console.log(a + 5);
// console.log(a+5);
// console.log(a+=5);//! a = a+5 = 15
// console.log(a+=5);
// console.log(a-=5);//! a= a-5 = 5
// console.log(a*=5);//! 50
// console.log(a/=5);//
// console.log(a%=5);
// console.log(a**=2);
// console.log(a);

// ! relational operators

// console.log(10 == 10);
// console.log("Hi" == "Hi");
// console.log("10" == 10);

// console.log(10 === 10);
// console.log("10" === 10);

// console.log(10 != 10);
// console.log("10" != 10);
// console.log(100 != 10);

// console.log(10 !== 10);
// console.log("10" !== 10);

// console.log(10 > 5);
// console.log(10 >= 10);
// console.log(10 < 20);
// console.log(20 <= 20);

// console.log(true && true);
// console.log(true && false);
// console.log(false && true);
// console.log(false && false);

// console.log(true || true);
// console.log(true || false);
// console.log(false || true);
// console.log(false || false);
// console.log(!true);
// console.log(!false);