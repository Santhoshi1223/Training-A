// console.log(10);

// document.writeln(1000);

// var a =10;
//     a="Hi"; //? re-intitalization
// console.log(a);

// var user ="Mahesh";

// var user = "Ramesh";//?redeclaration
// console.log(user);


// let a =10;
//     a=100;//? re-intitalization
//     console.log(a);


// let b=10;
// let b=20;
// console.log(b); //?redecalaration not possible

// const dob = 1990;
// dob=2000;
// console.log(dob);

// const dob=1900;
// const dob=2000;
// console.log(dob);


// let str1 = "doublequotes";
// console.log(str1);
// console.log(typeof(str1));

// let str2 = 'singlequote';
// console.log(str2);
// console.log(typeof(str2));

// let str3 =`template literals`;
// console.log(str3);
// console.log(typeof(str3));


// let num1 = 10;
// console.log(num1 , typeof(num1));

// let num2 = 10.3456789;
// console.log(num2 , typeof(num2));

// let bool1 = true;
// console.log(bool1 , typeof(bool1));

// let bool2 = false;
// console.log(bool2 , typeof(bool2));

// let a;
// console.log(a , typeof(a));


// let a = null;
// console.log(a);
// console.log(typeof(null));

console.log(2n , typeof(2n));

