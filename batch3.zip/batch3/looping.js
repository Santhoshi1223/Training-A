// console.log("Good Morning!");
// console.log("Good Morning!");
// console.log("Good Morning!");
// console.log("Good Morning!");
// console.log("Good Morning!");

//!  for loop
// for(let i=1;i<=5;i++){
// console.log("Good Morning");
// }

// let n = 100;
// for(let i = 0 ; i<=n;i++)
// {
//     if(i%2 == 0){
//         console.log(i + " is a even number");
//     }else{
//         console.log(i + " is a odd number");
//     }
// }

// let i=1;
// while(i <= 5){
//     console.log("Good morning!!!");
//     i++;
// }

// let i = 1;
// let n=5;
// do{
//     i++;
//     console.log("Batch 3 is awesome , they are responding very welllllllllllllllll");
// }while(i<=n)

// for(let i=1; i<=10;i++){
//     console.log(i);
//     if(i == 5) break;
// }

// for(let i=1; i<=10;i++){
    
//     if(i == 3) continue;
//     console.log(i);
// }


